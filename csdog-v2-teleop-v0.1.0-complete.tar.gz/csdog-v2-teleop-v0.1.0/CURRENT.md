# 当前状态

更新时间：2026-10-29

## 2026-10-29：v0.1 QWEASD 仿真成果已冻结

- 冻结任务：`CSDog-V2-Teleop-Direct-v0`；
- 冻结版本：`csdog-v2-teleop-v0.1.0`；
- Isaac Sim 图形窗口中，`W/S` 前后、`A/D` 横移、`Q/E` 转向及常用双键联动均已人工验收；
- 默认遥控速度为前后 `0.35 m/s`、横移 `0.22 m/s`、转向 `0.35 rad/s`，命令平滑时间约 `0.20 s`；
- 最终策略包含 50 维观测（基础 48 维加步态相位正余弦）、12 维关节位置动作和 `0.50 s` 对角步态周期；
- 交付 checkpoint、兼容元数据和 ONNX；同环境电脑可直接运行，无需重新训练；
- 仍有高速左移不足、横移与转向组合偏弱、转向髋外展及机身轻微拧转等已知限制；
- 完整参数、训练路线、验收结果和复现步骤见 `docs/CSDOG_V2_V0_1_RELEASE_REPORT.md`。

## 2026-10-29：v2 独立模型静态门禁

- 起点 Git commit：`00ff66dd1dffe5d7c098475403cec58d389fcc18`；
- v2 已解压到独立目录 `assets/robots/csdog_v2`，未替换旧模型；
- 新增独立校准任务 `CSDog-V2-Calibration-Direct-v0`，训练入口当前强制拒绝该任务；
- URDF 结构检查 PASS：13 links、12 revolute joints、13 meshes、质量/惯性正定；
- 物理就绪检查 FAIL：统一模板关节限位缺乏真实来源，12 个 collision mesh 超过
  1000 triangles，独立足底接触几何尚未确认；
- 根据 stop-on-failure 规则，关节动态测试、30 秒站立、接触/步态测试和 PPO smoke 均
  标记为 `NOT_RUN`，没有启动长训练；
- 详细问题与 A/B/C 计划见 `docs/CSDOG_V2_AUDIT_AND_TRAINING_PLAN.md`。

## 当前目标

在已经通过 Linux 模型门禁的基础上，训练一个统一接收 `vx`、`vy`、
`yaw_rate` 的 locomotion PPO 策略。当前仍处于奖励和控制解耦验证阶段。

## 已完成

- SolidWorks 四足机器人建模和装配；
- 模型转换为 URDF + STL；
- 生成 Isaac Lab Direct RL 工程框架；
- 静态确认 13 个 link、12 个 revolute joint、12 维 action、48 维 observation；
- 静态确认 93 个 STL 文件齐全；
- Python 文件通过语法编译检查；
- 坐标已经转换为 Z-up、X-forward。
- 模型包 SHA256 与仓库文档一致，并已解压到 `/home/ni/robot_projects/csdog`；
- 自定义包以 `--no-deps -e` 安装，未改变黄金环境依赖版本；
- ROS `check_urdf` 通过，13 个 link、12 个 revolute joint、93 个 STL 均完整；
- 单环境 GUI 加载与 RTX/Fabric GPU 渲染通过；
- 已将默认直腿零位姿替换为镜像弯腿站姿；
- 出生高度已校准为 0.1527 m，目标站高为 0.1327 m，最低站高阈值为 0.08 m；
- 零动作连续站立 30 秒通过，无 reset、NaN、非足端接触或力矩饱和；
- 12 个关节的动作索引和 `+-0.1 rad` 方向测试通过；
- 8 环境、20 iteration PPO 冒烟训练通过并保存 checkpoint；
- checkpoint 的官方 play 加载、500 步推理和 5 iteration resume 通过；
- 修复命令采样未写回 command buffer 的问题，并验证单轴采样比例正常；
- 已验证机器人本体可以实现横移：v7b 在 `vy=0.5 m/s` 时达到平均
  `vy=0.533 m/s`，且无异常 termination；
- v12 从 v11 官方 resume 至累计 iteration 1498，新增 3,072,000 transitions，
  训练过程无 OOM、NaN 或 crash；
- v12 checkpoint 已通过官方 play 加载，并完成前进、横移、转向三个固定命令的
  16 环境、每环境 1000 步定量测试。
- v13 使用当前 v12 奖励从零训练 500 iterations，排除了失败仅由旧 checkpoint
  惯性造成的可能；
- v14 完全取消零命令正 tracking reward，确认缺少稳定课程时策略会频繁跌倒；
- v15 将零命令的 X/Y/Yaw tracking 各按 `1/3` 归一化，使站立与任一单轴命令的
  正 tracking 上限均为 5.0，并从零完成 500 iterations 训练及三轴验收。
- 训练入口新增可复现的 `--command_axes` 和 `--command_limit` 课程参数，单轴采样器
  只在实际启用的命令轴中抽样；
- v16 从已验证横移的 v7b checkpoint 继续只训练 Y 轴 200 iterations；
- v17 从 v16 继续在 `vy in [-0.3, 0.3]` 的低速范围训练 200 iterations。
- 当前有效的 `source/`、`scripts/`、精选 JSON 指标和交接文档已统一纳入 GitHub 仓库。
- 本机源码入口已统一为 `/home/ni/robot_projects/csdog` Git 工作区；旧训练产物完整归档，
  并通过被 Git 忽略的本地软链接继续保持 checkpoint 路径兼容。

## 当前已知问题

- 总质量为 `0.764637 kg`，来源为几何估算，尚未与实际设计核对；
- 所有关节统一使用 `+-1.57 rad / 10 N·m / 5 rad/s`，仍需按机械限位与电机参数校准；
- 93 个外观 STL 被同时用于碰撞，正式并行训练前需要简化；
- 训练后的可选 ONNX 自动导出报 `too many indices for tensor of dimension 2`，不影响 checkpoint、resume 或 play，尚未修复；
- 修复命令采样前的 checkpoint 只学习了零命令站立，不能作为 locomotion 模型；
- v12 保持站立且会转向，但尚未学会合格的三轴条件控制：
  `vx=0.30` 时实际平均 `vx=0.100 m/s`，`vy=0.15` 时实际平均
  `vy=0.041 m/s`，两种命令产生了近似相同的前进运动；
- v12 在 `yaw_rate=0.30 rad/s` 时达到平均 `0.191 rad/s`，但同时产生
  `vx=-0.190 m/s`、`vy=-0.282 m/s` 的明显串轴运动；
- v12 三项测试动作饱和率为 78.1%-82.8%，说明当前策略仍依赖大量裁剪动作；
- 因横移命令被忽略且串轴明显，当前不能宣称统一 locomotion 策略已经完成。
- v13 从零训练仍塌缩为低姿态近静止策略；零命令每步 reward 是前进测试的约 26 倍，
  证明原先零命令同时领取三项正奖励是实际漏洞；
- v14 去掉该奖励后最终 episode length 仅约 186，说明单纯删除站立学习信号也不可行；
- v15 最终 episode length 恢复到约 695，但固定命令测试仍未通过：
  `vx=0.30` 时实际 `vx=-0.005 m/s`，`vy=0.15` 时实际 `vy=-0.003 m/s`，
  `yaw_rate=0.30` 时实际 `0.096 rad/s`；平均高度约 0.093 m，动作饱和率 76%-91%；
- 当前证据表明联合从零训练缺少稳定的 locomotion curriculum，继续只调 reward 权重
  或增加 iterations 没有充分依据。
- v16 在 `vy=0.50` 时达到 `0.491 m/s`、无跌倒且串轴很小，但在 `vy=0.15`
  时仅达到 `0.024 m/s`，说明横移专家存在明显低速死区；
- v17 将动作饱和率降低到 60%-68%，但 `vy=0.15` 仍仅达到 `0.010 m/s`；
  `vy=0.30` 达到 `0.254 m/s`，同时出现 `vx=-0.128 m/s` 和较高足端滑动；
- 因低速门禁未通过，尚未进入 X+Y 或三轴课程，避免在不稳定基础上继续叠加任务。

## 下一步

1. 先解决单轴低速死区、横向运动的 X 串轴和足端滑动，再进入双轴课程；
2. 优先评估加入步态相位/足端目标或对称性约束，而不是继续仅调整标量 reward 权重；
3. 每个方案先做 Y 轴 `0.15/0.30/0.50 m/s` 三档门禁，再逐轴加入；
4. 每个课程阶段均检查非目标轴速度、base 高度、足端滑动和动作饱和率；
5. 三轴均通过定量门槛后，再做 GUI 跟随演示和更长训练；
6. 用真实 CAD/电机资料核对质量、惯量、机械限位、力矩和速度限制；
7. ONNX 是可选项，不能通过升级黄金环境依赖来修复。

## 阶段完成条件

- 单环境连续站立 30 秒；
- 12 个关节方向和映射正确；
- 无穿地、爆炸、NaN 或持续力矩饱和；
- 非足端没有持续接触地面；
- checkpoint 可以保存、加载并继续训练。
- 同一个 checkpoint 对正向 `vx`、`vy`、`yaw_rate` 均产生方向正确且有实质幅度的响应；
- 非目标轴速度受控，动作饱和率不再长期处于约 80%。
